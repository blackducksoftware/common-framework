package test0551;

public class A {
// some code
}
/*
// some comments